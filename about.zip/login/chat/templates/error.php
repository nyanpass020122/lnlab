<<?php ?>?xml version="1.0" encoding="UTF-8"?>
<!--
$Id: error.php,v 3.1 2012/06/04 18:15:37 confetto Exp $
$Name: release-3-0 $
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ja" lang="ja">

<head>
	<meta name="viewport" content="width=device-width" />
	<link rel="stylesheet" type="text/css" href="chat.css" />
	<link rel="contents" href="/" title="ホームに戻る" />
	<link rev="made" href="http://confetto.s31.xrea.com/" />
	<title>エラーです</title>
</head>

<body>

<h1>エラーです</h1>

<pre><?php o($message)?></pre>

<div id="navigation">
	<h2>ページ移動</h2>
	<ul>
		<li><a href="/login/" rel="contents">管理パネルへ</a></li>
		<li><a href="<?php o($_SERVER['PHP_SELF'])?>">チャットに戻る</a></li>
	</ul>
</div>

<address>
	<a href="http://confetto.s31.xrea.com/" rev="made">chat/plain</a>
	<?php o($version)?>
</address>

</body>
</html>
