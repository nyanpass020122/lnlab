<?php
require 'user.php';
$lunaIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$lunaId.'/original');
$ichikaIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$ichikaId.'/original');
$hijiriIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$hijiriId.'/original');
$kijiniwaIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$kijiniwaId.'/original');
$karanasiIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$karanasiId.'/original');
$masaIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$masaId.'/original');
$nyanpassIcon = file_get_contents('http://furyu.nazo.cc/twicon/'.$nyanpassId.'/original');
