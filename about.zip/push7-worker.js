importScripts("https://aldebaran.push7.jp/ex-push7-worker.js");
